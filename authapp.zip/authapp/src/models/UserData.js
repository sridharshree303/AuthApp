class UserData{
    userid = 0;
    name;
    email;
    username;
    password;
    mobileNumber=0;
}

export default UserData;